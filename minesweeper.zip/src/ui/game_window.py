import tkinter as tk
from tkinter import ttk
import os
import sys

# Add the src directory to the Python path if needed
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))


class GameWindow:
    """
    Main window for the Minesweeper game.
    
    This class handles the UI layout and components.
    """
    
    def __init__(self, root=None):
        """
        Initialize the game window.
        
        Args:
            root (tk.Tk, optional): Root Tkinter window. If None, a new one is created.
        """
        # Initialize the root window if not provided
        if root is None:
            self.root = tk.Tk()
        else:
            self.root = root
        
        # Set window properties
        self.root.title("Minesweeper")
        self.root.resizable(False, False)
        self.root.configure(bg='#f0f0f0')  # Windows 7 background color
        
        # Set window size for a 16x16 grid
        # Each cell is approximately 25x25 pixels
        # Add extra space for the top panel and borders
        window_width = 16 * 25 + 20  # 16 cells * 25 pixels + padding
        window_height = 16 * 25 + 80  # 16 cells * 25 pixels + top panel + padding
        self.root.geometry(f"{window_width}x{window_height}")
        
        # Set grid size
        self.grid_size = (16, 16)
        
        # Create UI components
        self._create_widgets()
        
        # Apply Windows 7 style
        self._apply_windows7_style()
    
    def _create_widgets(self):
        """Create and arrange all UI widgets."""
        # Create top panel frame
        self.top_panel = tk.Frame(self.root, bg='#f0f0f0', height=60)
        self.top_panel.pack(fill=tk.X, padx=10, pady=10)
        
        # Create placeholder for mine counter (left side)
        self.mine_counter_frame = tk.Frame(self.top_panel, bg='#f0f0f0', width=80, height=40)
        self.mine_counter_frame.pack(side=tk.LEFT, padx=5)
        self.mine_counter_label = tk.Label(self.mine_counter_frame, text="000", font=("Digital-7", 20), bg='black', fg='red')
        self.mine_counter_label.pack(pady=5)
        
        # Create placeholder for restart button (center)
        self.restart_button_frame = tk.Frame(self.top_panel, bg='#f0f0f0')
        self.restart_button_frame.pack(side=tk.LEFT, expand=True, padx=5)
        self.restart_button = tk.Button(self.restart_button_frame, text="😊", font=("Arial", 16), width=2, height=1)
        self.restart_button.pack(pady=5)
        
        # Create placeholder for timer (right side)
        self.timer_frame = tk.Frame(self.top_panel, bg='#f0f0f0', width=80, height=40)
        self.timer_frame.pack(side=tk.RIGHT, padx=5)
        self.timer_label = tk.Label(self.timer_frame, text="000", font=("Digital-7", 20), bg='black', fg='red')
        self.timer_label.pack(pady=5)
        
        # Create game grid frame
        self.grid_frame = tk.Frame(self.root, bg='#c0c0c0', bd=2, relief=tk.SUNKEN)
        self.grid_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create a status bar (optional)
        self.status_bar = tk.Frame(self.root, bg='#f0f0f0', height=20)
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM)
        self.status_label = tk.Label(self.status_bar, text="Ready", bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(fill=tk.X)
        
        # Create placeholder grid cells
        self._create_grid_placeholders()
    
    def _create_grid_placeholders(self):
        """Create placeholder buttons for the grid."""
        self.cell_buttons = []
        
        for row in range(self.grid_size[0]):
            button_row = []
            for col in range(self.grid_size[1]):
                # Create a button for each cell
                btn = tk.Button(self.grid_frame, width=2, height=1, relief=tk.RAISED)
                btn.grid(row=row, column=col, padx=0, pady=0)
                button_row.append(btn)
            self.cell_buttons.append(button_row)
    
    def _apply_windows7_style(self):
        """Apply Windows 7 style to the UI components."""
        # Try to use ttk styles for a more native look
        style = ttk.Style()
        
        # Use the system theme if available
        try:
            style.theme_use('vista')  # Windows 7 theme
        except tk.TclError:
            try:
                style.theme_use('winnative')  # Fallback to Windows native theme
            except tk.TclError:
                pass  # Use default theme if neither is available
        
        # Configure button style
        style.configure('TButton', padding=2)
    
    def run(self):
        """Start the main event loop."""
        self.root.mainloop()


if __name__ == "__main__":
    # Create and run the game window for testing
    game_window = GameWindow()
    game_window.run()
