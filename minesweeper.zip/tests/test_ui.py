import unittest
import sys
import os
from unittest.mock import patch, MagicMock, Mock

# Add the src directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Mock tkinter before importing GameWindow
sys.modules['tkinter'] = Mock()
sys.modules['tkinter.ttk'] = Mock()

# Now import GameWindow which will use the mocked tkinter
from src.ui.game_window import GameWindow


class TestGameWindow(unittest.TestCase):
    @patch('tkinter.Tk')
    @patch('tkinter.Frame')
    @patch('tkinter.Label')
    @patch('tkinter.Button')
    def setUp(self, mock_button, mock_label, mock_frame, mock_tk):
        """Set up a new game window for each test"""
        self.mock_tk = mock_tk
        self.mock_frame = mock_frame
        self.mock_label = mock_label
        self.mock_button = mock_button
        
        # Create a mock root window
        self.root = MagicMock()
        
        # Create the game window with the mock root
        self.game_window = GameWindow(self.root)
    
    def test_window_title(self):
        """Test that the window title is set correctly"""
        # Verify that title was called with 'Minesweeper'
        self.root.title.assert_called_with("Minesweeper")
    
    def test_window_resizable(self):
        """Test that the window is not resizable"""
        # Verify that resizable was called with False, False
        self.root.resizable.assert_called_with(False, False)
    
    def test_window_size(self):
        """Test that the window size is appropriate for a 16x16 grid"""
        # Verify that geometry was called with a string containing dimensions
        # Extract the dimensions from the geometry call
        geometry_call = self.root.geometry.call_args[0][0]
        width, height = map(int, geometry_call.split('x'))
        
        # Window should be large enough for a 16x16 grid plus controls
        self.assertGreaterEqual(width, 400)  # Minimum width
        self.assertGreaterEqual(height, 450)  # Minimum height
    
    def test_grid_size(self):
        """Test that the grid size is set to 16x16"""
        self.assertEqual(self.game_window.grid_size, (16, 16))
    
    def test_ui_components_created(self):
        """Test that all UI components are created"""
        # Check that the main UI components exist
        self.assertTrue(hasattr(self.game_window, 'top_panel'))
        self.assertTrue(hasattr(self.game_window, 'grid_frame'))
        self.assertTrue(hasattr(self.game_window, 'status_bar'))
        
        # Check that the control components exist
        self.assertTrue(hasattr(self.game_window, 'mine_counter_label'))
        self.assertTrue(hasattr(self.game_window, 'timer_label'))
        self.assertTrue(hasattr(self.game_window, 'restart_button'))
        
        # Check that the cell buttons are created
        self.assertTrue(hasattr(self.game_window, 'cell_buttons'))
        
    def test_cell_buttons_grid(self):
        """Test that the cell buttons grid is created with correct dimensions"""
        # Check that cell_buttons is a list with 16 rows
        self.assertEqual(len(self.game_window.cell_buttons), 16)
        
        # Check that each row has 16 buttons
        for row in self.game_window.cell_buttons:
            self.assertEqual(len(row), 16)


if __name__ == '__main__':
    unittest.main()
